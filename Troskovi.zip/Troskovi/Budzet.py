'''Program koji vodi racuna o vasim racunima :D!'''
#RESITI:
#problem1 ---> kad se nova kategorija ubaci u sql bazu- ubacuje samo poslednju ubacenu vrednost(time samo i poslednju mozemo da insertujemo u nasu bazu)
#problem2 ---> bitmap nece da cita kad se unzippuje

#SLEDECE:
#kad se ne unose datum, da datum= timestamp!
#napravi kalendar pop-up

from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import pymysql

#Pravljenje prazne liste u slucaju praznog .txt filea
m=[]
try:
	dok=open("budzet.txt",'r')
	for line in dok:
		m=line.split(",")
		print(m)
except:
	pass

print(m)
	
dok=open("budzet.txt",'a')

#Liste za combobox
lista_1=["Voda","Struja","Hrana","Spanski","Tenis","Sok","Izlaci","Fiksni","SBB","Infostan","Popravke", "Doktori", "Garderoba","Benzin"]+m
lista_2=["Ivan","Zeljka","Dragana"]

root=Tk()


"""------------------------------------------------------------STILOVI-----------------------------------------------------------------"""

#Pravljenje stilova
ttk.Style().configure("darkblue.TButton", foreground="#0F1E27", justify= CENTER, font=("Helvetica",12))
ttk.Style().configure("darkblue2.TButton", foreground="#0F1E27", font=("Helvetica",10))
ttk.Style().configure("bluegray.TFrame", background="#12181B")
ttk.Style().configure("bluegray2.TFrame", background="#273A46", foreground="#6B9D85")
ttk.Style().configure("green/blue.TLabel", foreground="#1A8BD5", background="#273A46", font=("Helvetica",10))
ttk.Style().configure("green/blue1.TLabel", foreground="#1A8BD5", background="#12181B", font=("Helvetica",10))
ttk.Style().configure("green/blue2.TLabel", foreground="#1A8BD5", background="#273A46", font=("Helvetica",14))
ttk.Style().configure("green/blue21.TLabel", foreground="#1A8BD5", background="#12181B", font=("Helvetica",14))
ttk.Style().configure("green/blue22.TLabel", foreground="#1A8BD5", background="#12181B", font=("Helvetica",36))
ttk.Style().configure("green/blue3.TLabel", foreground="#707070", background="#273A46", font=("Helvetica",10))
ttk.Style().configure("purple.TEntry", foreground="#13142B", background="black",font=("Helvetica",12))
ttk.Style().configure("purple2.TEntry", foreground="#13142B", background="black",font=("Helvetica",10))
ttk.Style().configure("Ivan.Treeview", background="#4F517C", foreground="white")
ttk.Style().configure("Ivan.Treeview.Heading", background="#4F517C", foreground="#1A8BD5")
ttk.Style().configure("green/blue1.TRadiobutton", foreground="#1A8BD5", background="#12181B", font=("Helvetica",10))



"""------------------------------------------------------------SLIKE---------------------------------------------------------------------"""
#Root config/slike i ikone
root.title("Troškovi")
root.configure(background="#12181B")
#root.iconbitmap('2.ico ')
slika=PhotoImage(file='2.gif')
slika=slika.subsample(50)
dugmepoz=PhotoImage(file="pozadina.png")
dugmepoz=dugmepoz.subsample(18)



"""------------------------------------------------------------FRAMEOVI---------------------------------------------------------------------"""
#FRAMEOVI
ram=ttk.Frame(root, style= "bluegray.TFrame", relief=SUNKEN)
ram.grid(column=0, row=0)

unos=ttk.Frame(ram, style= "bluegray2.TFrame")
unos.grid(column=0, row=0, padx=10, pady=10, sticky=(N,E,S,W))

okvirdugmadunos=ttk.Frame(ram, style= "bluegray.TFrame")
okvirdugmadunos.grid(column=0, row=1, padx=10, pady=10, sticky=(N,E,S,W))

unosunos=ttk.Frame(okvirdugmadunos, style= "bluegray2.TFrame")
unosunos.grid(column=1, row=0, padx=10, pady=10, sticky=(N,E,S,W))

dugmad=ttk.Frame(okvirdugmadunos, style="bluegray.TFrame")
dugmad.grid(column=0, row=0)

treeviewg=ttk.Frame(ram, style="bluegray2.TFrame")
treeviewg.grid(column=0, row=2,padx=10, pady=10,sticky=(N,W,E,S))

pretrazi=ttk.Frame(treeviewg, style="bluegray.TFrame")
pretrazi.grid(column=0, row=0, padx=10, pady=10,sticky=(N,W,E,S))

zbirram=ttk.Frame(ram, style="bluegray.TFrame")
zbirram.grid(column=0, row=3, sticky=(N,W,E,S))


"""------------------------------------------------------------FUNKCIJE---------------------------------------------------------------------"""

def closethis(*args):
	'''Funkcija da li ste sigurni...'''
	if messagebox.askyesno("Izlaz","Jeste li sigurni da hocete da izadjete?"):
		dok.close()
		root.destroy()
		
root.protocol("WM_DELETE_WINDOW", closethis)
	

def prikazisve(*args):
	'''Funkcija koja ispisuje bazu u treeview'''
	brisi()
	db=pymysql.connect("localhost","root","","budzet")
	cursor=db.cursor()
	cursor.execute("""SELECT tip,iznos,datum,korisnik from troskovi;""")
	for row in cursor:
		tree.insert("","end", values=(row[0],row[1],row[2],row[3]))
	try:
		db.commit()
	except:
		db.rollback()
	db.close()
	katVar.set("")
	iznosVar.set("")
	datumVar.set("2017-MM-DD")	
	novakatVar.set("")


def unesitrosak (*args):
	if not datumVar.get()=="2017-MM-DD":
		'''Unesi trosak u SQL bazu'''
		if katVar.get()=="" or korVar.get()=="" or iznosVar.get()=="":
				messagebox.showinfo("Greska","Morate uneti sve podatke osim datuma!")
		else:
			try:
				morabroj=int(iznosVar.get())
				tree.insert("", 0, values=(katVar.get(),morabroj,datumVar.get(),korVar.get()))
				
				db=pymysql.connect("localhost","root","","budzet")
				cursor=db.cursor()
				komanda1="INSERT INTO troskovi(korisnik,tip,iznos,datum) VALUES('{}', '{}', '{}','{}');".format(korVar.get(), katVar.get(), iznosVar.get(), datumVar.get())
				try:
					cursor.execute(komanda1)
					db.commit()
				except:
					db.rollback()
				katVar.set("")
				iznosVar.set("")
				datumVar.set("2017-MM-DD")
				korVar.set("")
			except ValueError:
				messagebox.showinfo("Greska","Unesite broj kao iznos!")
	else:
		if katVar.get()=="" or korVar.get()=="" or iznosVar.get()=="":
				messagebox.showinfo("Greska","Morate uneti sve podatke osim datuma!")
		else:
			try:
				morabroj=int(iznosVar.get())
				tree.insert("", 0, values=(katVar.get(),morabroj,"",korVar.get()))
				
				db=pymysql.connect("localhost","root","","budzet")
				cursor=db.cursor()
				komanda1="INSERT INTO troskovi(korisnik,tip,iznos,datum) VALUES('{}', '{}', '{}','{}');".format(korVar.get(), katVar.get(), iznosVar.get(), "2017-02-03")
				try:
					cursor.execute(komanda1)
					db.commit()
				except:
					db.rollback()
				katVar.set("")
				iznosVar.set("")
				datumVar.set("2017-MM-DD")
				korVar.set("")
			except ValueError:
				messagebox.showinfo("Greska","Unesite broj kao iznos!")
			
def obrisiSelektovano():
    try:
        selected_item = tree.selection()[0]
        tree.delete(selected_item)
    except IndexError:
        messagebox.showinfo('Greska', 'Izaberi red za brisanje, ili radi nesto drugo!')

def unesikat (*args):
	
	'''Funkcija koja unosi novu kategoriju u bazu i .txt file'''	
	
	try:
		hi=","
		uzmivar=novakatVar.get()
		db=pymysql.connect("localhost","root","","budzet")
		cursor=db.cursor()
		lista_1.append(uzmivar)
		b=tuple(lista_1)
		komanda='''ALTER TABLE troskovi MODIFY COLUMN tip ENUM("Voda","Struja","Hrana","Spanski","Tenis","Kafa","Izlasci","SBB","Fixni","InfoStan","Garderoba", "Benzin", "Popravke", "Doktori","{}") NOT NULL;'''.format(uzmivar)
		
		kategorija['values'] = (lista_1)
		try:
			if not uzmivar=="":
				dok.write(novakatVar.get()+",")
			else:
				print("empty")
			cursor.execute(komanda)
			db.commit()	
		except:
			db.rollback()
		db.close()
		novakatVar.set("")
	except ValueError:
		messagebox.showinfo("Greska","Negde se pogresili?!")


def brisi(*args):
	'''Funkcija koja brise sve iz treeviewa'''
	for i in tree.get_children():
		tree.delete(i)
	racunVar.set("")


def pretraziDb():
	'''Pretrazi po korisniku,datumu,kateriji...'''
	if opcija.get()=='ko':
		brisi()
		db=pymysql.connect("localhost", "root", "", "budzet")
		cursor=db.cursor()
		command1=("SELECT tip,iznos,datum,korisnik FROM troskovi WHERE korisnik='{}';".format(srcVar.get()))
		cursor.execute(command1)
		rezultat= cursor.fetchall()
		if not rezultat:
			messagebox.showinfo('Obavestenje', 'Osoba sa trazenim imenom nije u bazi!')
		db.commit()
		for red in rezultat:
			tree.insert('','end', values=(red[0], red[1], red[2], red[3]))
		db.close()	
		srcVar.set("")
	elif opcija.get()=='ka':
		brisi()
		db=pymysql.connect("localhost", "root", "", "budzet")
		cursor=db.cursor()
		command1=("SELECT tip,iznos,datum,korisnik FROM troskovi WHERE tip='{}';".format(srcVar.get()))
		cursor.execute(command1)
		rezultat= cursor.fetchall()
		if not rezultat:
			messagebox.showinfo('Obavestenje', 'Takva kategorija ne postoji! Dodajte je u bazu!')
		db.commit()
		for red in rezultat:
			tree.insert('','end', values=(red[0], red[1], red[2],  red[3]))
		db.close()
		srcVar.set("")
	elif opcija.get()=='d':
		brisi()
		db=pymysql.connect("localhost", "root", "", "budzet")
		cursor=db.cursor()
		command1=("SELECT tip,iznos,datum,korisnik FROM troskovi WHERE datum='{}';".format(srcVar.get()))
		cursor.execute(command1)
		rezultat= cursor.fetchall()
		if not rezultat:
			messagebox.showinfo('Obavestenje', 'Tog datuma navodno nista nije potreseno!')
		db.commit()
		for red in rezultat:
			tree.insert('','end', values=(red[0], red[1], red[2],  red[3]))
		db.close()
		srcVar.set("")
	else:
		messagebox.showinfo('Greska', 'Morate odabrati nacin pretrage!')		
		
def zbir(*args):
	'''Funkcija koja sabira ukupan iznos u treeviewu'''
	children=tree.get_children()
	lista=[]
	for child in children:
		i= tree.item(child, "values")[1]
		lista.append(int(i))
	ukupno=(sum(lista))
	racunVar.set(ukupno)
	katVar.set("")
	iznosVar.set("")
	datumVar.set("2017-MM-DD")
	korVar.set("")
	novakatVar.set("")
	


#FILE MENI
glavnimenu=Menu(root)
root.configure(menu=glavnimenu)
glavnimenu.configure(background="#12181B")

filemenu=Menu(glavnimenu, tearoff=0)
glavnimenu.add_cascade(label="File", menu=filemenu)
filemenu.add_command(label="Ispisi bazu", command=prikazisve)
filemenu.add_command(label="Refresh", accelerator='Del', compound=LEFT, command=brisi)
filemenu.add_command(label="Izlaz", accelerator='Esc', compound=LEFT, image=slika, command=closethis)
filemenu.configure(background="#12181B", foreground="#1A8BD5")



#varijable
katVar=StringVar()
iznosVar=StringVar()
datumVar=StringVar(value='2017-MM-DD')
novakatVar=StringVar()
korVar=StringVar()
opcija= StringVar()
srcVar=StringVar()
racunVar=IntVar(value='')



#Unos frame
kor=ttk.Label(unos,text="Korisnik", style="green/blue2.TLabel" ).grid(row=0,column=0)
korisnik= ttk.Combobox(unos, textvariable=korVar)
korisnik.grid(row=1,column=0)
korisnik['values'] = (lista_2)

kat=ttk.Label(unos,text="Kategorija", style="green/blue2.TLabel" ).grid(row=0,column=1)
kategorija= ttk.Combobox(unos, textvariable=katVar)
kategorija.grid(row=1,column=1)
kategorija['values'] = (lista_1)

iznos=ttk.Label(unos,text="Iznos", style="green/blue2.TLabel" ).grid(row=0,column=2)
iznosE=ttk.Entry(unos, style="purple.TEntry", justify='center', textvariable=iznosVar).grid(row=1,column=2)

datum=ttk.Label(unos,text="Datum", style="green/blue2.TLabel" ).grid(row=0,column=3)
datum2=ttk.Label(unos,text="YYYY-MM-DD", style="green/blue3.TLabel" ).grid(row=2,column=3)
datumE=ttk.Entry(unos, style="purple.TEntry", justify='center', textvariable=datumVar)
datumE.grid(row=1,column=3)



#Novakategorija
novakat=ttk.Label(unosunos, text="Nema zeljene kategorije na spisku? \nDodaj novu kategoriju", justify="center", style="green/blue.TLabel" ).grid(row=0,column=0)
novakatE=ttk.Entry(unosunos, style="purple.TEntry", justify='center', textvariable=novakatVar).grid(row=1,column=0)



#Dugmici
unesitros=ttk.Button(dugmad, text="Unesi",style="darkblue.TButton", command=unesitrosak)
unesitros.grid(column=0,row=0)
unesitros.config(image=dugmepoz, compound=CENTER)

prika=ttk.Button(dugmad, text="Prikazi sve",style="darkblue.TButton", command=prikazisve)
prika.grid(column=1,row=0)
prika.config(image=dugmepoz, compound=CENTER)

bris=ttk.Button(dugmad, text="Briši",style="darkblue.TButton", command=brisi)
bris.grid(column=2,row=0)
bris.config(image=dugmepoz, compound=CENTER)

katbut=ttk.Button(unosunos, text="Ubaci novu \nkategoriju",style="darkblue2.TButton", command=unesikat)
katbut.grid(column=0,row=3)

pretraziBut=ttk.Button(pretrazi, text="Pretrazi",style="darkblue2.TButton", command=pretraziDb)
pretraziBut.grid(column=0,row=5)


brisiselekBut=ttk.Button(dugmad, text="Obrisi\nSelektovano", style="darkblue.TButton", command=obrisiSelektovano)
brisiselekBut.grid(column=3,row=0)
brisiselekBut.config(image=dugmepoz, compound=CENTER)

izracunajBut=ttk.Button(zbirram, text="Izracunaj iznos\nu tabeli",style="darkblue.TButton", command=zbir)
izracunajBut.grid(column=4,row=0)
izracunajBut.config(image=dugmepoz, compound=CENTER)



#treeview frame
tree = ttk.Treeview(treeviewg)
tree['show']=('headings')
tree["columns"]=("prva","druga", "treca", "cetvrta")
tree.heading("prva", text="Kategorija")
tree.heading("druga", text="Iznos")
tree.heading("treca", text="Datum")
tree.heading("cetvrta", text="Uneo korisnik:")
tree.grid(column=1, row=0, columnspan=2, sticky=(E,W))

#scrollbar
scrollbar = ttk.Scrollbar(treeviewg,orient=VERTICAL, command=tree.yview)
scrollbar.grid(column=3, row=0,sticky=(N,S))
tree['yscrollcommand'] = scrollbar.set
tree.configure(style="Ivan.Treeview")


#radiobuttons
trazi=ttk.Label(pretrazi,text="Prikazi po ", style="green/blue21.TLabel" ).grid(row=0,column=0)
trazie=Entry(pretrazi, justify='center', textvariable=srcVar).grid(row=1,column=0)

imeSearch = ttk.Radiobutton(pretrazi, text='Korisniku', variable=opcija, value='ko', style="green/blue1.TRadiobutton").grid(row=2, column=0, sticky=W)
katSearch= ttk.Radiobutton(pretrazi, text='Kategoriji', variable=opcija, value='ka', style="green/blue1.TRadiobutton").grid(row=3, column=0, sticky=W)
datumSearch= ttk.Radiobutton(pretrazi, text='Datumu', variable=opcija, value='d', style="green/blue1.TRadiobutton").grid(row=4, column=0, sticky=W)




#Saberi
jednako=ttk.Label(zbirram,textvariable=racunVar, style="green/blue22.TLabel" ).grid(row=0,column=2)

"""------------------------------------------Konfiguracija redova i kolona---------------------------------------------------------------"""

root.columnconfigure(0,weight=1, min=500)
root.rowconfigure(0,weight=1,min=500)
ram.columnconfigure(0, weight=1)
ram.columnconfigure(1, weight=1)
ram.columnconfigure(2, weight=1)
ram.columnconfigure(3, weight=1)


ram.rowconfigure(0, weight=1)
ram.rowconfigure(1, weight=1)
ram.rowconfigure(2, weight=1)
ram.rowconfigure(3, weight=1)
ram.rowconfigure(4, weight=1)
ram.rowconfigure(5, weight=1)

unos.columnconfigure(0, weight=1)
unos.columnconfigure(1, weight=1)
unos.columnconfigure(2, weight=1)
unos.columnconfigure(3, weight=1)

unos.rowconfigure(0, weight=1)
unos.rowconfigure(1, weight=1)
unos.rowconfigure(2, weight=1)
unos.rowconfigure(3, weight=1)
unos.rowconfigure(4, weight=1)


okvirdugmadunos.columnconfigure(0, weight=1)
okvirdugmadunos.columnconfigure(1, weight=1)
okvirdugmadunos.columnconfigure(2, weight=1)
okvirdugmadunos.rowconfigure(0, weight=1)
okvirdugmadunos.rowconfigure(1, weight=1)
okvirdugmadunos.rowconfigure(2, weight=1)

treeviewg.columnconfigure(0, weight=1)
treeviewg.columnconfigure(1, weight=1)
treeviewg.columnconfigure(2, weight=1)
treeviewg.columnconfigure(3, weight=1)
treeviewg.columnconfigure(4, weight=1)
treeviewg.rowconfigure(0, weight=1)
treeviewg.rowconfigure(1, weight=1)
treeviewg.rowconfigure(2, weight=1)

unosunos.columnconfigure(0, weight=1)
unosunos.rowconfigure(0, weight=1)
unosunos.rowconfigure(1, weight=1)
unosunos.rowconfigure(2, weight=1)


dugmad.columnconfigure(0, weight=1)
dugmad.columnconfigure(1, weight=1)
dugmad.columnconfigure(2, weight=1)
dugmad.columnconfigure(3, weight=1)
dugmad.rowconfigure(0, weight=1)
dugmad.rowconfigure(1, weight=1)

pretrazi.columnconfigure(0, weight=1)
pretrazi.columnconfigure(1, weight=1)
pretrazi.columnconfigure(2, weight=1)
pretrazi.columnconfigure(3, weight=1)
pretrazi.rowconfigure(0, weight=1)
pretrazi.rowconfigure(1, weight=1)
pretrazi.rowconfigure(2, weight=1)
pretrazi.rowconfigure(3, weight=1)
pretrazi.rowconfigure(4, weight=1)
pretrazi.rowconfigure(5, weight=1)


zbirram.columnconfigure(0, weight=1)
zbirram.columnconfigure(1, weight=1)
zbirram.columnconfigure(2, weight=1)
zbirram.columnconfigure(3, weight=1)
zbirram.columnconfigure(4, weight=1)
zbirram.rowconfigure(0, weight=1)
zbirram.rowconfigure(1, weight=1)

#padding izmedju redova
for a in ram.winfo_children(): a.grid_configure(padx=7,pady=7)
for a in unos.winfo_children(): a.grid_configure(padx=2,pady=5)
for a in treeviewg.winfo_children(): a.grid_configure(padx=5,pady=5)
for a in okvirdugmadunos.winfo_children(): a.grid_configure(padx=5,pady=5)
for a in unosunos.winfo_children(): a.grid_configure(padx=5,pady=5)
for a in pretrazi.winfo_children(): a.grid_configure(padx=5,pady=5)
for a in zbirram.winfo_children(): a.grid_configure(padx=5,pady=5)


korisnik.focus()
root.bind("<Delete>", brisi)
root.bind("<Escape>", closethis)
root.mainloop()
